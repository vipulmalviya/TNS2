import React, { Fragment, useState } from 'react'
import { MdArrowForward } from 'react-icons/md'
const CategoryPage = () => {
    const array = [
        {
            category: "AcademyWinner",
            value: "Academy Winner",
        },
        {
            category: "AcademyWinner",
            value: "Around the Globe",
        },
        {
            category: "AcademyWinner",
            value: "Academy Winner",
        },
        {
            category: "AcademyWinner",
            value: "User’s Choice",
        },
        {
            category: "AcademyWinner",
            value: "Handpicked",
        },
        {
            category: "AcademyWinner",
            value: "Classics",
        },
        {
            category: "AcademyWinner",
            value: "Family Friendly",
        },
        {
            category: "AcademyWinner",
            value: "Film Festival Favourtives",
        },
        {
            category: "AcademyWinner",
            value: "Film Festival Favourtives",
        },
        {
            category: "AcademyWinner",
            value: "Film Festival Favourtives",
        },
    ]

    const [Par, setPar] = useState("movie")

    function category(params) {
        setPar(params.target.innerText)
    }
    


    return (
        <Fragment>
            <section className='pt-0'>
                <div className='container innerContianer d-flex gap-2 align-items-start'>
                    <div className="dropdown">
                        <button className=" dropdown-toggle d-flex align-items-center justify-content-center" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <h6>{Par}</h6>
                        </button>
                        <ul className="dropdown-menu" >
                            <li><button onClick={category} className="dropdown-item" type="button"><MdArrowForward />TV Series</button></li>
                            <li><button onClick={category}  className="dropdown-item" type="button"><MdArrowForward />Movies</button></li>
                            <li><button onClick={category}  className="dropdown-item" type="button"><MdArrowForward />Curated List</button></li>
                        </ul>
                    </div>
                    <button data-name="topRated" className='Categorybtns Active'>
                        Top Rated
                    </button>
                    {array.map((elem, index) => {
                        return <button key={index} data-name={elem.category} className='Categorybtns Active'>
                            {elem.value}
                        </button>
                    })}
                </div>
            </section>
        </Fragment>
    )
}

export default CategoryPage
